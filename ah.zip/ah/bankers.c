#include<stdio.h>
void function(int a[4])
{
    int i=0;
    for(i=0;i<3;i++)
        printf("%d,",a[i]);
    printf("%d\t\t",a[i]);
}

void main()
{
    char ans='n';
    while(1)
    {
        int allocation[5][4]={{0,0,1,2},{1,0,0,0},{1,3,5,4},{0,6,3,2},{0,0,1,4}};
        int max_allocation[5][4]={{0,0,1,2},{1,7,5,0},{2,3,5,6},{0,6,5,2},{1,6,5,6}};
        int available[4]={1,5,2,0},wait[5]={0,1,2,3,4};
        int need[5][4],execute[5];
        int i,j,k=0,l=0,len=5,count=0,e=0,p;
        if(ans=='y' || ans=='Y')
        {
            for(i=0;i<4;i++)
                scanf("%d",&allocation[p][i]);
            fflush(stdin);
        }
        printf("\nProcess\t\tAllocation\tMax Allocation\tNeed\n");
        for(i=0;i<5;i++)
        {
            for(j=0;j<4;j++)
                need[i][j]= max_allocation[i][j]-allocation[i][j];
            printf("%d\t\t",i);
            function(allocation[i]);
            function(max_allocation[i]);
            function(need[i]);
            printf("\n");
        }
        printf("Available: ");
        function(available);
        for(i=0;i<len;i++)
        {
            for(j=0;j<4;j++)
            {
                if(need[i][j] > available[j])
                {
                    for(j=0;j<4;j++)
                    {
                        allocation[k][j]=allocation[i][j];
                        need[k][j]=need[i][j];
                    }
                    wait[k]=i;
                    k++;
                    l=1;
                    break;
                }
            }
            if(l==0)
            {
                for(j=0;j<4;j++)
                    available[j]=available[j]+allocation[i][j];
                execute[e++]=wait[i];
            }
            else
                l=0;
            if(i==(len-1) && k>0)
            {
                len=k;
                i=-1;
                k=0;
                count++;
            }
            if(count==5)
                break;
        }
        if(count<5)
        {
            printf("\n\nThe System is in safe state and sequence of execution is: ");
            for(i=0;i<4;i++)
                printf("%d,",execute[i]);
            printf("%d\n",execute[i]);
        }
        else
            printf("\n\nThe System is not in safe state\n");
        printf("\nDo you want to add a new process? (Y/N): ");
        scanf("%c",&ans);
        if(ans!='Y' && ans!='y')
            break;
        fflush(stdin);
        printf("\nEnter Process Number to add (0-4): ");
        scanf("%d",&p);
        printf("Enter allocation values for p%d: ",p);
    }
}
