import static java.lang.Thread.sleep;
import java.util.HashMap;
import java.util.Scanner;

public class ElectionAlgorithm {
    public static void main(String[] args) throws InterruptedException {
        Scanner sc = new Scanner(System.in);

        HashMap<Integer, Boolean> process = new HashMap<>();
        process.put(1, Boolean.TRUE);
        process.put(2, Boolean.TRUE);
        process.put(3, Boolean.TRUE);
        process.put(4, Boolean.TRUE);
        process.put(5, Boolean.TRUE);
        int proc;
        HashMap<Integer, Integer> pc = new HashMap<>();
        pc.put(1, 5);
        pc.put(2, 5);
        pc.put(3, 5);
        pc.put(4, 5);
        int curr_pc = 5;
        do {
            System.out.println("**** MENU ****");
            System.out.println("Process Co-ordinator : " + curr_pc);
            System.out.print("Down List: [ ");
            for (int k = 1; k <= 5; k++) {
                if (!process.get(k)) {
                    System.out.print(k + " ");
                }
            }
            System.out.println("]");
            System.out.println("1. Process 1");
            System.out.println("2. Process 2");
            System.out.println("3. Process 3");
            System.out.println("4. Process 4");
            System.out.println("5. Process 5");
            System.out.println("Press 0 to exit ");
            System.out.print("Enter your choice : ");
            proc = sc.nextInt();
            if (proc > 0 && proc < 5) {
                Boolean loop;
                do {
                    loop = Boolean.FALSE;
                    if (process.get(proc)) {
                        System.out.println("1. Make it Down");
                        if (pc.get(proc) != proc) {
                            System.out.println("2. Request to PC ");
                        }
                    } else {
                        System.out.println("1. Make it Up");
                    }
                    System.out.println("Press 0 to exit ");
                    System.out.print("Enter your choice : ");
                    int ch2 = sc.nextInt();
                    switch (ch2) {
                        case 1:
                            process.put(proc, !process.get(proc));
                            if (!process.get(proc)) {
                                break;
                            }
                        case 2:
                            if (process.get(proc)) {
                                if (!process.get(pc.get(proc))) {
                                    System.out.println("Co-ordinator down. Election will be held");
                                    System.out.println("Election Ongoing......");
                                    sleep(300);
                                    int j;
                                    for (j = 5; j > 0; j--) {
                                        if (process.get(j)) {
                                            for (int k = 1; k < 5; k++) {
                                                if (process.get(k)) {
                                                    pc.put(k, j);
                                                }
                                            }
                                            break;
                                        }
                                    }
                                    for (int k = proc + 1; k <= j; k++) {
                                        if (process.get(k)) {
                                            System.out.println("Process " + k + " is alive");
                                        }
                                    }
                                    System.out.println("Election done. Process " + j + " is the new coordinator");
                                    curr_pc = j;
                                } else if (ch2 == 2) {
                                    System.out.println("Co-ordinator will serve the request");
                                }
                            } else {
                                System.out.println("Invalid Input");
                            }
                            break;
                        case 0:
                            break;
                        default:
                            System.out.println("Invalid Input");
                            loop = Boolean.TRUE;
                    }
                } while (loop);
            } else if (proc == 5) {
                if (process.get(proc)) {
                    System.out.print("Make it Down? (Y/N) : ");
                } else {
                    System.out.print("Make it Up? (Y/N) : ");
                }
                char choice = sc.next().charAt(0);
                if (choice == 'Y' || choice == 'y') {
                    process.put(proc, !process.get(proc));
                    if (curr_pc != 5 && process.get(proc)) {
                        System.out.println("Highest priority ");
                        System.out.println("Process " + proc + " is the new coordinator");
                        for (int k = 1; k < 5; k++) {
                            if (process.get(k)) {
                                pc.put(k, 5);
                            }
                        }
                        curr_pc = 5;
                    }
                }
            } else if (proc >= 6 && proc < 0) {
                System.out.println("Invalid Choice");
            } else {
                System.out.println("Exiting.........");
            }
            System.out.println("---------------------------------------------------");
        } while (proc != 0);
    }
}