import java.rmi.*;
import java.rmi.server.*;
public class Client
{
public static void main(String[]arg) throws Exception
{
RmiExample r=(RmiExample)Naming.lookup("rmi://localhost/add");
System.out.println("The Addition of a+b"+r.add(5,5));
}
}
